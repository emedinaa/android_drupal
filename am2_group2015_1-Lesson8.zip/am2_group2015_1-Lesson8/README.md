# am2_group2015_1
Aplicaciones Móviles 2 - Android ISIL


###Conexion Remota

###Volley 
https://developer.android.com/training/volley/index.html

###PARSE.COM
https://parse.com/

https://www.parse.com/apps

1. Crear nueva aplicación

2. Ir a core

3. Agregar nueva clase "User"

4. Agregar nueva fila

5. Agregar nueva columna


###Credenciales
https://www.parse.com/apps/app_am2_isil/edit#keys


###Referencia 
https://www.parse.com/docs

###Arquitectura REST&Webservices
http://users.dsic.upv.es/~rnavarro/NewWeb/docs/RestVsWebServices.pdf

Postman
https://chrome.google.com/webstore/detail/postman-rest-client-packa/fhbjgbiflinjbdggehcddcbncdddomop




