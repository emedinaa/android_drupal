package com.isil.am2.examplerest.view.listeners;

/**
 * Created by emedinaa on 19/05/15.
 */
public interface OnFragmentListener {
}
